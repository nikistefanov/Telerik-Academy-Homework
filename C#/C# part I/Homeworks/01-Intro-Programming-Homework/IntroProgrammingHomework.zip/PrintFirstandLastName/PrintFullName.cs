﻿/*Problem 7. Print First and Last Name

Create console application that prints your first and last name, each at a separate line.*/

using System;


class PrintFullName
{
    static void Main()
    {
        Console.Title = "Howdy";
        Console.WriteLine("John");
        Console.WriteLine("Codarski");
    }
}

