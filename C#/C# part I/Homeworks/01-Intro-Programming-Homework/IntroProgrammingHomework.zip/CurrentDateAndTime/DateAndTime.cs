﻿/*Problem 14.* Current Date and Time

Create a console application that prints the current date and time. Find out how in Internet.*/

using System;

class DateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}
