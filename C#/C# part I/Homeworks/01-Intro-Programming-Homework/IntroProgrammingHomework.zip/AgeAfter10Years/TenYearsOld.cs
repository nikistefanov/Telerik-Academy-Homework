﻿/*Problem 15.* Age after 10 Years

Write a program to read your birthday from the console and print how old you are now and how old you will be after 10 years.*/

using System;
using System.Globalization;
using System.Threading;

class TenYearsOld
{
    static void Main()
    {
        CultureInfo bg = new CultureInfo("bg-BG");                    // Set the current culture to Bulgaria
        Thread.CurrentThread.CurrentCulture = bg;                     //  
        Console.ForegroundColor = ConsoleColor.Green;                 // This will change the font colour, just for fun :)
        Console.Title = "Age Calculator";
        Console.WriteLine("Now we are going to calculate how old will you be in 10 years! \nExcting, yes?");
        Console.Write("Enter your birthday: ");       
        DateTime birthDate = DateTime.Parse(Console.ReadLine());    
        int age = DateTime.Now.Year - birthDate.Year;
               
        if (DateTime.Now.Day == birthDate.Day && DateTime.Now.Month == birthDate.Month)  // Using this method will show me if the user has BD today
        {
            System.Media.SystemSounds.Asterisk.Play();
            Console.WriteLine("Hey it's you birthday today!");
            Thread.Sleep(1000);
        }
        if (birthDate.Year <= 1900)
        {
            Console.WriteLine("Hey! You're not that old!");
        }
        else
        {
            Console.WriteLine("In ten years you'll be {0} years old!", age + 10); 
        }              
    }
}
