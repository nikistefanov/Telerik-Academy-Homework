﻿namespace ExamPractise.Interfaces
{
    public interface IOffsiteCourse : ICourse
    {
        string Town { get; set; }
    }
}
