﻿namespace ExamPractise.Interfaces
{
    public interface ILocalCourse : ICourse
    {
        string Lab { get; set; }
    }
}
